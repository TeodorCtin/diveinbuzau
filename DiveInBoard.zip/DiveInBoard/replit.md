# DiveIn - Job Board Application

## Overview

DiveIn is a simplified job board application designed specifically for young people to discover and apply for opportunities in education, volunteering, internships, and events. The application features a dark-mode interface with neon blue accents and provides separate functionality for organizations (who can post opportunities) and young people (who can view and apply for opportunities without creating accounts).

The application is built as a full-stack web application with a React frontend and Express.js backend, using Supabase PostgreSQL for data persistence. The system supports user authentication for organizations, opportunity management, and application submission with both internal email tracking and external link redirects.

## Recent Updates

### Latest Features Added (January 2025)
- **Forgot Password System**: Complete modal-based password recovery with backend endpoint
- **Advanced Search & Filters**: Text search, category filtering, and location-based filtering for opportunities
- **Enhanced Authentication Flow**: Integrated forgot password into login modal with proper navigation
- **Database Connection**: Fixed Supabase integration with corrected DATABASE_URL format
- **Hybrid Storage System**: Fallback mechanism that uses database when available, in-memory storage otherwise

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Styling**: TailwindCSS with Radix UI components for consistent design system
- **Routing**: Wouter for client-side routing (lightweight alternative to React Router)
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Form Handling**: React Hook Form with Zod validation for type-safe form validation
- **UI Components**: Comprehensive component library using Radix UI primitives with custom styling

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Session-based authentication with bcrypt for password hashing
- **API Design**: RESTful API endpoints with proper error handling and validation
- **Storage Interface**: Abstracted storage layer with in-memory implementation for development

### Database Design
- **Users Table**: Stores organization credentials and information
- **Opportunities Table**: Contains job/opportunity listings with categories, descriptions, and contact information
- **Applications Table**: Tracks applications submitted by young people with personal details and messages
- **Schema Validation**: Zod schemas for runtime type checking and validation

### Design System
- **Theme**: Dark mode only with consistent color variables
- **Primary Colors**: Dark background (#171515) with neon blue accents (#007BFF)
- **Typography**: System fonts with proper hierarchy and spacing
- **Interactive Elements**: Hover effects with subtle glow animations
- **Responsive Design**: Mobile-first approach with proper breakpoints

### Authentication & Authorization
- **Session Management**: Server-side sessions for organization authentication
- **Password Security**: Encrypted password storage using bcrypt
- **Access Control**: Organization-specific opportunity management
- **Public Access**: Anonymous access for viewing opportunities and submitting applications

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe database ORM with PostgreSQL dialect
- **express**: Web application framework for Node.js
- **react**: Frontend UI library
- **@tanstack/react-query**: Server state management and caching

### UI & Styling Dependencies
- **tailwindcss**: Utility-first CSS framework
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **class-variance-authority**: Utility for creating variant-based component APIs
- **clsx**: Utility for constructing className strings

### Form & Validation Dependencies
- **react-hook-form**: Performant forms with easy validation
- **@hookform/resolvers**: Validation resolvers for React Hook Form
- **zod**: TypeScript-first schema validation
- **drizzle-zod**: Integration between Drizzle ORM and Zod validation

### Authentication & Security Dependencies
- **bcrypt**: Password hashing library
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### Development & Build Dependencies
- **vite**: Fast build tool and development server
- **typescript**: Static type checking
- **tsx**: TypeScript execution environment for Node.js
- **esbuild**: Fast JavaScript bundler for production builds
- **wouter**: Minimalist routing library for React

### Utility Dependencies
- **date-fns**: Modern JavaScript date utility library
- **nanoid**: URL-safe unique ID generator
- **cmdk**: Command menu component for search functionality
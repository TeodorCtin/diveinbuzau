import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertOpportunitySchema, InsertOpportunity } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

export default function AddOpportunityForm() {
  const [charCount, setCharCount] = useState(0);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<InsertOpportunity>({
    resolver: zodResolver(insertOpportunitySchema),
    defaultValues: {
      titlu: "",
      descriere: "",
      categorie: "",
      data: "",
      locatie: "",
      contact_email: null,
      link_extern: null,
      imagine_url: null,
      user_id: null,
    },
  });

  const createOpportunityMutation = useMutation({
    mutationFn: (data: InsertOpportunity) => 
      apiRequest('POST', '/api/opportunities', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      form.reset();
      setCharCount(0);
      toast({
        title: "Oportunitate publicată!",
        description: "Oportunitatea ta a fost adăugată cu succes și este acum vizibilă.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Eroare",
        description: error.message || "A apărut o eroare la publicarea oportunității",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertOpportunity) => {
    createOpportunityMutation.mutate(data);
  };

  return (
    <section id="add-opportunity" className="py-16 px-4 sm:px-6 lg:px-8 card-bg">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold mb-4">Adaugă o Oportunitate</h3>
          <p className="text-muted">Contribuie la comunitate și ajută alți tineri să-și găsească drumul</p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="titlu"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-primary">Titlu Oportunitate *</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="Ex: Stagiu Marketing Digital"
                        className="primary-bg border-color text-primary"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="categorie"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-primary">Categorie *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="primary-bg border-color text-primary">
                          <SelectValue placeholder="Selectează categoria" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="primary-bg border-color">
                        <SelectItem value="educatie">Educație</SelectItem>
                        <SelectItem value="ong">ONG</SelectItem>
                        <SelectItem value="stagii">Stagii</SelectItem>
                        <SelectItem value="evenimente">Evenimente</SelectItem>
                        <SelectItem value="altele">Altele</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="descriere"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-primary">Descriere *</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      rows={4}
                      maxLength={1000}
                      placeholder="Descrie oportunitatea în maximum 1000 de caractere..."
                      className="primary-bg border-color text-primary"
                      onChange={(e) => {
                        field.onChange(e);
                        setCharCount(e.target.value.length);
                      }}
                    />
                  </FormControl>
                  <div className="text-right text-sm text-muted">
                    {charCount}/1000 caractere
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="data"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-primary">Data *</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="date"
                        className="primary-bg border-color text-primary"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="locatie"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-primary">Locație *</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="Ex: București, Online"
                        className="primary-bg border-color text-primary"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="imagine_url"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-primary">URL Imagine</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      type="url"
                      placeholder="https://example.com/image.jpg"
                      className="primary-bg border-color text-primary"
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="contact_email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-primary">Email Contact</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="email"
                        placeholder="contact@example.com"
                        className="primary-bg border-color text-primary"
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="link_extern"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-primary">Link Extern</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="url"
                        placeholder="https://example.com/apply"
                        className="primary-bg border-color text-primary"
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="text-center">
              <Button 
                type="submit" 
                disabled={createOpportunityMutation.isPending}
                className="btn-primary px-8 py-3 text-lg font-medium"
              >
                {createOpportunityMutation.isPending ? "Se publică..." : "Publică Oportunitatea"}
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </section>
  );
}

export default function Hero() {
  const scrollToOpportunities = () => {
    document.getElementById('opportunities')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToAddForm = () => {
    document.getElementById('add-opportunity')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-5xl font-bold mb-6">
          Descoperă <span className="neon-blue">oportunități</span> pentru viitorul tău
        </h2>
        <p className="text-xl text-muted mb-8 max-w-2xl mx-auto">
          Platformă dedicată tinerilor pentru a găsi stagii, programe educaționale, 
          oportunități de voluntariat și evenimente care îți pot schimba viitorul.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button 
            onClick={scrollToOpportunities}
            className="btn-primary px-8 py-3 rounded-lg text-white font-medium text-lg"
          >
            Explorează Oportunități
          </button>
          <button 
            onClick={scrollToAddForm}
            className="border-2 border-primary text-primary px-8 py-3 rounded-lg font-medium text-lg hover:bg-primary hover:text-white transition-all duration-300"
          >
            Adaugă Oportunitate
          </button>
        </div>
      </div>
    </section>
  );
}

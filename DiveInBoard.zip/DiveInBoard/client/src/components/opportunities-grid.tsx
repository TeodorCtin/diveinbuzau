import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Opportunity } from "@shared/schema";
import { MapPin } from "lucide-react";
import ApplicationModal from "./modals/application-modal.tsx";
import SearchFilters from "./search-filters";

const categoryColors = {
  educatie: "bg-primary text-white",
  ong: "bg-green-500 text-white",
  stagii: "bg-purple-500 text-white",
  evenimente: "bg-yellow-500 text-white",
  altele: "bg-red-500 text-white"
};

const categoryLabels = {
  educatie: "Educație",
  ong: "ONG",
  stagii: "Stagii",
  evenimente: "Evenimente",
  altele: "Altele"
};

export default function OpportunitiesGrid() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [locationFilter, setLocationFilter] = useState("");

  const { data: opportunities = [], isLoading } = useQuery<Opportunity[]>({
    queryKey: ['/api/opportunities'],
  });

  const filteredOpportunities = useMemo(() => {
    let filtered = opportunities;

    // Search query filter
    if (searchQuery) {
      filtered = filtered.filter(opp => 
        opp.titlu.toLowerCase().includes(searchQuery.toLowerCase()) ||
        opp.descriere.toLowerCase().includes(searchQuery.toLowerCase()) ||
        opp.locatie.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Category filter
    if (categoryFilter) {
      filtered = filtered.filter(opp => opp.categorie === categoryFilter);
    } else if (selectedCategory !== "all") {
      filtered = filtered.filter(opp => opp.categorie === selectedCategory);
    }

    // Location filter
    if (locationFilter) {
      filtered = filtered.filter(opp => 
        opp.locatie.toLowerCase().includes(locationFilter.toLowerCase())
      );
    }

    return filtered;
  }, [opportunities, searchQuery, categoryFilter, selectedCategory, locationFilter]);

  const filters = [
    { key: "all", label: "Toate" },
    { key: "educatie", label: "Educație" },
    { key: "ong", label: "ONG" },
    { key: "stagii", label: "Stagii" },
    { key: "evenimente", label: "Evenimente" },
    { key: "altele", label: "Altele" }
  ];

  if (isLoading) {
    return (
      <section id="opportunities" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12 text-center">
            <h3 className="text-3xl font-bold mb-4">Oportunități Disponibile</h3>
            <p className="text-muted">Se încarcă oportunitățile...</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="card-bg rounded-xl p-6 animate-pulse">
                <div className="w-full h-48 bg-gray-700 rounded-lg mb-4"></div>
                <div className="h-4 bg-gray-700 rounded mb-2"></div>
                <div className="h-4 bg-gray-700 rounded w-3/4 mb-4"></div>
                <div className="h-12 bg-gray-700 rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <>
      <section id="opportunities" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12 text-center">
            <h3 className="text-3xl font-bold mb-4">Oportunități Disponibile</h3>
            <p className="text-muted">Filtrează și găsește oportunitatea perfectă pentru tine</p>
          </div>
          
          <div className="mb-8">
            <SearchFilters
              onSearch={setSearchQuery}
              onCategoryFilter={setCategoryFilter}
              onLocationFilter={setLocationFilter}
              searchQuery={searchQuery}
              categoryFilter={categoryFilter}
              locationFilter={locationFilter}
            />
          </div>
          
          {/* Filter Bar */}
          <div className="mb-8 flex flex-wrap gap-4 justify-center">
            {filters.map(filter => (
              <button
                key={filter.key}
                onClick={() => setSelectedCategory(filter.key)}
                className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                  selectedCategory === filter.key
                    ? "bg-primary text-white"
                    : "card-bg text-muted hover:bg-primary hover:text-white"
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>

          {/* Opportunities Grid */}
          {filteredOpportunities.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted text-lg">
                {selectedCategory === "all" 
                  ? "Nu există oportunități disponibile în acest moment." 
                  : `Nu există oportunități în categoria "${categoryLabels[selectedCategory as keyof typeof categoryLabels]}".`}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredOpportunities.map((opportunity) => (
                <div 
                  key={opportunity.id} 
                  className="card-bg rounded-xl p-6 glow-hover transition-all duration-300"
                >
                  {opportunity.imagine_url && (
                    <img 
                      src={opportunity.imagine_url} 
                      alt={opportunity.titlu}
                      className="w-full h-48 object-cover rounded-lg mb-4"
                    />
                  )}
                  
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex flex-col gap-2">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        categoryColors[opportunity.categorie as keyof typeof categoryColors] || "bg-gray-500 text-white"
                      }`}>
                        {categoryLabels[opportunity.categorie as keyof typeof categoryLabels] || opportunity.categorie}
                      </span>
                      {opportunity.link_extern && (
                        <span className="px-2 py-1 rounded text-xs bg-blue-500/20 text-blue-400 border border-blue-500/30 self-start">
                          Link extern
                        </span>
                      )}
                    </div>
                    <span className="text-muted text-sm">{opportunity.data}</span>
                  </div>
                  
                  <h4 className="text-xl font-semibold mb-3">{opportunity.titlu}</h4>
                  <p className="text-muted mb-4 line-clamp-3">
                    {opportunity.descriere}
                  </p>
                  
                  <div className="flex items-center mb-4 text-sm text-muted">
                    <MapPin className="w-4 h-4 mr-2" />
                    <span>{opportunity.locatie}</span>
                  </div>
                  
                  <button 
                    onClick={() => setSelectedOpportunity(opportunity)}
                    className="w-full btn-primary py-3 rounded-lg text-white font-medium"
                  >
                    {opportunity.link_extern ? "Aplică Extern" : "Aplică Acum"}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <ApplicationModal 
        opportunity={selectedOpportunity}
        isOpen={!!selectedOpportunity}
        onClose={() => setSelectedOpportunity(null)}
      />
    </>
  );
}

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Opportunity, Application } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Edit, Trash2, Users } from "lucide-react";

interface DashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
}

export default function DashboardModal({ isOpen, onClose, onLogout }: DashboardModalProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: opportunities = [], isLoading } = useQuery<Opportunity[]>({
    queryKey: ['/api/my-opportunities'],
    enabled: isOpen,
  });

  const deleteOpportunityMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/opportunities/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/my-opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      toast({
        title: "Oportunitate ștearsă",
        description: "Oportunitatea a fost ștearsă cu succes.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Eroare",
        description: error.message || "A apărut o eroare la ștergerea oportunității",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (id: string, title: string) => {
    if (confirm(`Ești sigur că vrei să ștergi oportunitatea "${title}"?`)) {
      deleteOpportunityMutation.mutate(id);
    }
  };

  const stats = {
    totalOpportunities: opportunities.length,
    totalApplications: 0, // This would require additional API calls per opportunity
    recentViews: 0, // This would require view tracking
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="card-bg border-color text-primary max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Dashboard Organizație</DialogTitle>
        </DialogHeader>
        
        {/* Dashboard Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="primary-bg p-6 rounded-lg">
            <div className="text-2xl font-bold neon-blue">{stats.totalOpportunities}</div>
            <div className="text-muted">Oportunități Publicate</div>
          </div>
          <div className="primary-bg p-6 rounded-lg">
            <div className="text-2xl font-bold text-green-500">{stats.totalApplications}</div>
            <div className="text-muted">Aplicații Primite</div>
          </div>
          <div className="primary-bg p-6 rounded-lg">
            <div className="text-2xl font-bold text-yellow-500">{stats.recentViews}</div>
            <div className="text-muted">Vizualizări Această Lună</div>
          </div>
        </div>
        
        {/* Organization Opportunities */}
        <div className="mb-8">
          <h4 className="text-xl font-semibold mb-4">Oportunitățile Tale</h4>
          
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="primary-bg p-6 rounded-lg animate-pulse">
                  <div className="h-4 bg-gray-700 rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-gray-700 rounded w-1/2 mb-4"></div>
                  <div className="h-4 bg-gray-700 rounded w-1/4"></div>
                </div>
              ))}
            </div>
          ) : opportunities.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted text-lg">Nu ai publicat încă nicio oportunitate.</p>
              <p className="text-muted">Folosește formularul de mai jos pentru a adăuga prima ta oportunitate!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {opportunities.map((opportunity) => (
                <div key={opportunity.id} className="primary-bg p-6 rounded-lg flex justify-between items-start">
                  <div className="flex-1">
                    <h5 className="font-semibold text-lg mb-2">{opportunity.titlu}</h5>
                    <p className="text-muted mb-2 line-clamp-2">{opportunity.descriere}</p>
                    <div className="flex items-center space-x-4 text-sm text-muted">
                      <span className="capitalize">{opportunity.categorie}</span>
                      <span>{opportunity.locatie}</span>
                      <span>{opportunity.data}</span>
                    </div>
                  </div>
                  <div className="flex space-x-2 ml-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toast({ title: "În curând", description: "Funcția de editare va fi disponibilă în curând." })}
                      className="text-primary hover:neon-blue p-2"
                    >
                      <Edit className="w-5 h-5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(opportunity.id, opportunity.titlu)}
                      disabled={deleteOpportunityMutation.isPending}
                      className="text-red-500 hover:text-red-400 p-2"
                    >
                      <Trash2 className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Logout Button */}
        <div className="text-center">
          <Button 
            onClick={onLogout}
            variant="ghost"
            className="text-red-500 hover:text-red-400 font-medium"
          >
            Deconectează-te
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

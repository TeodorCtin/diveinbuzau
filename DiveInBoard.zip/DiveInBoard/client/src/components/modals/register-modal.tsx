import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema, InsertUser } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { authKey } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

interface RegisterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSwitchToLogin: () => void;
}

export default function RegisterModal({ isOpen, onClose, onSwitchToLogin }: RegisterModalProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<InsertUser>({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      email: "",
      password: "",
      nume_organizatie: "",
    },
  });

  const registerMutation = useMutation({
    mutationFn: (data: InsertUser) => apiRequest('POST', '/api/auth/register', data),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: authKey });
      onClose();
      form.reset();
      toast({
        title: "Cont creat cu succes!",
        description: "Bun venit în DiveIn! Acum te poți conecta.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Eroare la înregistrare",
        description: error.message || "A apărut o eroare la crearea contului",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertUser) => {
    registerMutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="card-bg border-color text-primary">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Înregistrare Organizație</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="nume_organizatie"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nume Organizație</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      placeholder="Ex: TechHub România"
                      className="primary-bg border-color"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      type="email"
                      placeholder="contact@organizatie.com"
                      className="primary-bg border-color"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Parolă</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      type="password"
                      placeholder="••••••••"
                      className="primary-bg border-color"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              disabled={registerMutation.isPending}
              className="w-full btn-primary"
            >
              {registerMutation.isPending ? "Se creează contul..." : "Creează Cont"}
            </Button>
          </form>
        </Form>
        
        <div className="text-center">
          <p className="text-muted">Ai deja cont? {" "}
            <button 
              onClick={onSwitchToLogin}
              className="neon-blue hover:underline"
            >
              Conectează-te
            </button>
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { ArrowLeft } from "lucide-react";

const forgotPasswordSchema = z.object({
  email: z.string().email("Email invalid"),
});

type ForgotPasswordData = z.infer<typeof forgotPasswordSchema>;

interface ForgotPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBackToLogin: () => void;
}

export default function ForgotPasswordModal({ isOpen, onClose, onBackToLogin }: ForgotPasswordModalProps) {
  const [emailSent, setEmailSent] = useState(false);
  const { toast } = useToast();

  const form = useForm<ForgotPasswordData>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      email: "",
    },
  });

  const forgotPasswordMutation = useMutation({
    mutationFn: (data: ForgotPasswordData) => apiRequest('POST', '/api/auth/forgot-password', data),
    onSuccess: () => {
      setEmailSent(true);
      toast({
        title: "Email trimis",
        description: "Verifică emailul pentru instrucțiuni de resetare a parolei.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Eroare",
        description: error.message || "A apărut o eroare la trimiterea emailului",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: ForgotPasswordData) => {
    forgotPasswordMutation.mutate(data);
  };

  const handleClose = () => {
    setEmailSent(false);
    form.reset();
    onClose();
  };

  const handleBackToLogin = () => {
    setEmailSent(false);
    form.reset();
    onBackToLogin();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="primary-bg border-color">
        <DialogHeader>
          <DialogTitle className="text-center text-primary">
            {emailSent ? "Email trimis" : "Resetare parolă"}
          </DialogTitle>
        </DialogHeader>

        {emailSent ? (
          <div className="space-y-4 py-4">
            <p className="text-center text-muted-foreground">
              Ți-am trimis un email cu instrucțiuni pentru resetarea parolei.
              Verifică inbox-ul și folder-ul de spam.
            </p>
            <div className="flex gap-2">
              <Button 
                onClick={handleBackToLogin}
                variant="outline" 
                className="flex-1"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Înapoi la login
              </Button>
              <Button onClick={handleClose} className="flex-1">
                Închide
              </Button>
            </div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email organizație</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="email"
                        placeholder="email@organizatie.ro"
                        className="primary-bg border-color"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex gap-2 pt-4">
                <Button 
                  type="button"
                  onClick={handleBackToLogin}
                  variant="outline" 
                  className="flex-1"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Înapoi
                </Button>
                <Button 
                  type="submit" 
                  disabled={forgotPasswordMutation.isPending}
                  className="flex-1"
                >
                  {forgotPasswordMutation.isPending ? "Se trimite..." : "Trimite email"}
                </Button>
              </div>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}
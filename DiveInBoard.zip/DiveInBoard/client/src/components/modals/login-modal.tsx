import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { authKey } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const loginSchema = z.object({
  email: z.string().email("Email invalid"),
  password: z.string().min(1, "Parola este obligatorie"),
});

type LoginForm = z.infer<typeof loginSchema>;

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSwitchToRegister: () => void;
  onSwitchToForgotPassword: () => void;
}

export default function LoginModal({ isOpen, onClose, onSwitchToRegister, onSwitchToForgotPassword }: LoginModalProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const loginMutation = useMutation({
    mutationFn: (data: LoginForm) => apiRequest('POST', '/api/auth/login', data),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: authKey });
      onClose();
      form.reset();
      toast({
        title: "Conectat cu succes!",
        description: "Bun venit înapoi în DiveIn.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Eroare la conectare",
        description: error.message || "Email sau parolă incorectă",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: LoginForm) => {
    loginMutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="card-bg border-color text-primary">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Login Organizație</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      type="email"
                      placeholder="organizatie@example.com"
                      className="primary-bg border-color"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Parolă</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      type="password"
                      placeholder="••••••••"
                      className="primary-bg border-color"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              disabled={loginMutation.isPending}
              className="w-full btn-primary"
            >
              {loginMutation.isPending ? "Se conectează..." : "Conectează-te"}
            </Button>
          </form>
        </Form>
        
        <div className="text-center space-y-2">
          <button 
            onClick={onSwitchToForgotPassword}
            className="text-sm text-muted-foreground hover:neon-blue transition-colors"
          >
            Ai uitat parola?
          </button>
          <p className="text-muted">Nu ai cont? {" "}
            <button 
              onClick={onSwitchToRegister}
              className="neon-blue hover:underline"
            >
              Înregistrează-te
            </button>
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

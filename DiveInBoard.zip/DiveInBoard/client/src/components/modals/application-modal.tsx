import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertApplicationSchema, InsertApplication, Opportunity } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

interface ApplicationModalProps {
  opportunity: Opportunity | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function ApplicationModal({ opportunity, isOpen, onClose }: ApplicationModalProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<InsertApplication>({
    resolver: zodResolver(insertApplicationSchema),
    defaultValues: {
      oportunitate_id: "",
      nume: "",
      prenume: "",
      email: "",
      link_social: "",
      mesaj: "",
    },
  });

  const applicationMutation = useMutation({
    mutationFn: (data: InsertApplication) => apiRequest('POST', '/api/applications', data),
    onSuccess: (response: any) => {
      onClose();
      form.reset();
      
      // Show success message from server
      toast({
        title: "Aplicația a fost trimisă!",
        description: response.message || "Aplicația ta a fost trimisă cu succes.",
      });
      
      // If there's a redirect URL from server, redirect to it
      if (response.redirect_url) {
        setTimeout(() => {
          window.open(response.redirect_url, '_blank');
          toast({
            title: "Redirectionare",
            description: "Te-am redirecționat către link-ul extern pentru a continua procesul.",
          });
        }, 1500);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Eroare",
        description: error.message || "A apărut o eroare la trimiterea aplicației",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertApplication) => {
    if (!opportunity) return;
    
    applicationMutation.mutate({
      ...data,
      oportunitate_id: opportunity.id,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="card-bg border-color text-primary">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">
            Aplică pentru: {opportunity?.titlu}
          </DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="nume"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nume *</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="Popescu"
                        className="primary-bg border-color"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="prenume"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prenume *</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="Andrei"
                        className="primary-bg border-color"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email *</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      type="email"
                      placeholder="andrei.popescu@example.com"
                      className="primary-bg border-color"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="link_social"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Link Social Media *</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      type="url"
                      placeholder="https://instagram.com/username"
                      className="primary-bg border-color"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="mesaj"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Mesaj (opțional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      rows={4}
                      placeholder="De ce te interesează această oportunitate?"
                      className="primary-bg border-color"
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              disabled={applicationMutation.isPending}
              className="w-full btn-primary"
            >
              {applicationMutation.isPending ? "Se trimite..." : "Trimite Aplicația"}
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { authKey } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import LoginModal from "./modals/login-modal.tsx";
import RegisterModal from "./modals/register-modal.tsx";
import DashboardModal from "./modals/dashboard-modal.tsx";
import ForgotPasswordModal from "./modals/forgot-password-modal.tsx";
import { useToast } from "@/hooks/use-toast";

export default function Header() {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showDashboardModal, setShowDashboardModal] = useState(false);
  const [showForgotPasswordModal, setShowForgotPasswordModal] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: user, isLoading } = useQuery<User | null>({
    queryKey: authKey,
    queryFn: async () => {
      try {
        const response = await fetch('/api/auth/me', { credentials: 'include' });
        if (response.status === 401) return null;
        if (!response.ok) throw new Error('Failed to fetch user');
        return response.json();
      } catch {
        return null;
      }
    },
  });

  const logoutMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/auth/logout'),
    onSuccess: () => {
      queryClient.setQueryData(authKey, null);
      setShowDashboardModal(false);
      toast({
        title: "Deconectat cu succes",
        description: "Ai fost deconectat din cont.",
      });
    },
  });

  const scrollToOpportunities = () => {
    document.getElementById('opportunities')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToAddForm = () => {
    document.getElementById('add-opportunity')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <>
      <header className="bg-card-bg border-b border-color sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-bold neon-blue">DiveIn</h1>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <button 
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="text-primary hover:neon-blue transition-colors duration-200"
              >
                Acasă
              </button>
              <button 
                onClick={scrollToOpportunities}
                className="text-primary hover:neon-blue transition-colors duration-200"
              >
                Oportunități
              </button>
              <button 
                onClick={scrollToAddForm}
                className="text-primary hover:neon-blue transition-colors duration-200"
              >
                Adaugă Oportunitate
              </button>
            </nav>
            
            <div className="flex items-center space-x-4">
              {isLoading ? (
                <div className="w-8 h-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
              ) : user ? (
                <>
                  <span className="text-primary text-sm">
                    Bună, {user.nume_organizatie}!
                  </span>
                  <button 
                    onClick={() => setShowDashboardModal(true)}
                    className="text-primary hover:neon-blue transition-colors duration-200"
                  >
                    Dashboard
                  </button>
                  <button 
                    onClick={handleLogout}
                    className="text-primary hover:text-red-400 transition-colors duration-200"
                    disabled={logoutMutation.isPending}
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <button 
                    onClick={() => setShowLoginModal(true)}
                    className="text-primary hover:neon-blue transition-colors duration-200"
                  >
                    Login
                  </button>
                  <button 
                    onClick={() => setShowRegisterModal(true)}
                    className="btn-primary px-4 py-2 rounded-lg text-white font-medium"
                  >
                    Înregistrare Organizație
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      <LoginModal 
        isOpen={showLoginModal} 
        onClose={() => setShowLoginModal(false)}
        onSwitchToRegister={() => {
          setShowLoginModal(false);
          setShowRegisterModal(true);
        }}
        onSwitchToForgotPassword={() => {
          setShowLoginModal(false);
          setShowForgotPasswordModal(true);
        }}
      />
      
      <RegisterModal 
        isOpen={showRegisterModal} 
        onClose={() => setShowRegisterModal(false)}
        onSwitchToLogin={() => {
          setShowRegisterModal(false);
          setShowLoginModal(true);
        }}
      />

      <ForgotPasswordModal 
        isOpen={showForgotPasswordModal} 
        onClose={() => setShowForgotPasswordModal(false)} 
        onBackToLogin={() => {
          setShowForgotPasswordModal(false);
          setShowLoginModal(true);
        }}
      />

      {user && (
        <DashboardModal 
          isOpen={showDashboardModal} 
          onClose={() => setShowDashboardModal(false)}
          onLogout={handleLogout}
        />
      )}
    </>
  );
}

import { useState } from "react";
import { Search, Filter, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

interface SearchFiltersProps {
  onSearch: (query: string) => void;
  onCategoryFilter: (category: string | null) => void;
  onLocationFilter: (location: string) => void;
  searchQuery: string;
  categoryFilter: string | null;
  locationFilter: string;
}

const categories = [
  { value: "educatie", label: "Educație" },
  { value: "ong", label: "ONG & Voluntariat" },
  { value: "internship", label: "Internship" },
  { value: "stagiu", label: "Stagiu" },
  { value: "eveniment", label: "Eveniment" },
  { value: "curs", label: "Curs" },
];

export default function SearchFilters({
  onSearch,
  onCategoryFilter,
  onLocationFilter,
  searchQuery,
  categoryFilter,
  locationFilter,
}: SearchFiltersProps) {
  const [showFilters, setShowFilters] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onSearch(e.target.value);
  };

  const handleLocationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onLocationFilter(e.target.value);
  };

  const clearFilters = () => {
    onSearch("");
    onCategoryFilter(null);
    onLocationFilter("");
  };

  const activeFiltersCount = [searchQuery, categoryFilter, locationFilter].filter(Boolean).length;

  return (
    <div className="space-y-4">
      {/* Search bar */}
      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Caută oportunități..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="pl-10 pr-12 primary-bg border-color"
        />
        <Button
          onClick={() => setShowFilters(!showFilters)}
          variant="outline"
          size="sm"
          className="absolute right-2 top-2 h-8 w-8 p-0"
        >
          <Filter className="h-4 w-4" />
        </Button>
      </div>

      {/* Filter badge */}
      {activeFiltersCount > 0 && (
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {activeFiltersCount} filtre active
          </Badge>
          <Button
            onClick={clearFilters}
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-xs"
          >
            <X className="h-3 w-3 mr-1" />
            Șterge toate
          </Button>
        </div>
      )}

      {/* Expanded filters */}
      {showFilters && (
        <div className="p-4 border border-border rounded-lg primary-bg space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Categorie</label>
              <Select
                value={categoryFilter || ""}
                onValueChange={(value) => onCategoryFilter(value || null)}
              >
                <SelectTrigger className="primary-bg border-color">
                  <SelectValue placeholder="Toate categoriile" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Toate categoriile</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Locație</label>
              <Input
                type="text"
                placeholder="București, Cluj, Online..."
                value={locationFilter}
                onChange={handleLocationChange}
                className="primary-bg border-color"
              />
            </div>
          </div>

          <div className="flex justify-between items-center pt-2">
            <span className="text-sm text-muted-foreground">
              Filtrează rezultatele pentru a găsi oportunități relevante
            </span>
            <Button
              onClick={() => setShowFilters(false)}
              variant="outline"
              size="sm"
            >
              Închide filtrele
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
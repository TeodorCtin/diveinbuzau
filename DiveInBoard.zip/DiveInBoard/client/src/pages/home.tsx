import Header from "@/components/header";
import Hero from "@/components/hero";
import OpportunitiesGrid from "@/components/opportunities-grid";
import AddOpportunityForm from "@/components/add-opportunity-form";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen primary-bg">
      <Header />
      <main>
        <Hero />
        
        {/* Quick Stats */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 card-bg">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
              <div className="space-y-2">
                <div className="text-3xl font-bold neon-blue">150+</div>
                <div className="text-muted">Oportunități Active</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold neon-blue">45+</div>
                <div className="text-muted">Organizații Partenere</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold neon-blue">500+</div>
                <div className="text-muted">Aplicații Trimise</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold neon-blue">85%</div>
                <div className="text-muted">Rata de Succes</div>
              </div>
            </div>
          </div>
        </section>

        <OpportunitiesGrid />
        <AddOpportunityForm />
      </main>
      <Footer />
    </div>
  );
}

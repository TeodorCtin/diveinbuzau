import { type User, type InsertUser, type Opportunity, type InsertOpportunity, type Application, type InsertApplication, users, opportunities, applications } from "@shared/schema";
import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import { eq, desc } from "drizzle-orm";
import { randomUUID } from "crypto";

let db: any = null;
let useDatabase = false;

// Try to initialize database connection
try {
  if (process.env.DATABASE_URL) {
    const sql = neon(process.env.DATABASE_URL);
    db = drizzle(sql);
    useDatabase = true;
  }
} catch (error) {
  console.warn("Database initialization failed, using in-memory storage");
  useDatabase = false;
}

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Opportunity methods
  getOpportunities(): Promise<Opportunity[]>;
  getOpportunity(id: string): Promise<Opportunity | undefined>;
  getOpportunitiesByUser(userId: string): Promise<Opportunity[]>;
  createOpportunity(opportunity: InsertOpportunity): Promise<Opportunity>;
  updateOpportunity(id: string, opportunity: Partial<Opportunity>): Promise<Opportunity | undefined>;
  deleteOpportunity(id: string): Promise<boolean>;

  // Application methods
  getApplications(): Promise<Application[]>;
  getApplicationsByOpportunity(opportunityId: string): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
}

export class HybridStorage implements IStorage {
  private memUsers: Map<string, User> = new Map();
  private memOpportunities: Map<string, Opportunity> = new Map();
  private memApplications: Map<string, Application> = new Map();

  async getUser(id: string): Promise<User | undefined> {
    if (useDatabase && db) {
      try {
        const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
        return result[0];
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    return this.memUsers.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    if (useDatabase && db) {
      try {
        const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
        return result[0];
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    return Array.from(this.memUsers.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    if (useDatabase && db) {
      try {
        const result = await db.insert(users).values(insertUser).returning();
        return result[0];
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    const id = randomUUID();
    const user: User = { ...insertUser, id, created_at: new Date() };
    this.memUsers.set(id, user);
    return user;
  }

  async getOpportunities(): Promise<Opportunity[]> {
    if (useDatabase && db) {
      try {
        return await db.select().from(opportunities).orderBy(desc(opportunities.created_at));
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    return Array.from(this.memOpportunities.values()).sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }

  async getOpportunity(id: string): Promise<Opportunity | undefined> {
    if (useDatabase && db) {
      try {
        const result = await db.select().from(opportunities).where(eq(opportunities.id, id)).limit(1);
        return result[0];
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    return this.memOpportunities.get(id);
  }

  async getOpportunitiesByUser(userId: string): Promise<Opportunity[]> {
    if (useDatabase && db) {
      try {
        return await db.select().from(opportunities)
          .where(eq(opportunities.user_id, userId))
          .orderBy(desc(opportunities.created_at));
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    return Array.from(this.memOpportunities.values())
      .filter(opportunity => opportunity.user_id === userId)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  async createOpportunity(insertOpportunity: InsertOpportunity): Promise<Opportunity> {
    if (useDatabase && db) {
      try {
        const result = await db.insert(opportunities).values(insertOpportunity).returning();
        return result[0];
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    const id = randomUUID();
    const opportunity: Opportunity = { 
      ...insertOpportunity, 
      id, 
      created_at: new Date(),
      user_id: insertOpportunity.user_id || null,
      contact_email: insertOpportunity.contact_email || null,
      link_extern: insertOpportunity.link_extern || null,
      imagine_url: insertOpportunity.imagine_url || null
    };
    this.memOpportunities.set(id, opportunity);
    return opportunity;
  }

  async updateOpportunity(id: string, updates: Partial<Opportunity>): Promise<Opportunity | undefined> {
    if (useDatabase && db) {
      try {
        const result = await db.update(opportunities)
          .set(updates)
          .where(eq(opportunities.id, id))
          .returning();
        return result[0];
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    const existing = this.memOpportunities.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...updates };
    this.memOpportunities.set(id, updated);
    return updated;
  }

  async deleteOpportunity(id: string): Promise<boolean> {
    if (useDatabase && db) {
      try {
        const result = await db.delete(opportunities).where(eq(opportunities.id, id)).returning();
        return result.length > 0;
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    return this.memOpportunities.delete(id);
  }

  async getApplications(): Promise<Application[]> {
    if (useDatabase && db) {
      try {
        return await db.select().from(applications).orderBy(desc(applications.created_at));
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    return Array.from(this.memApplications.values()).sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }

  async getApplicationsByOpportunity(opportunityId: string): Promise<Application[]> {
    if (useDatabase && db) {
      try {
        return await db.select().from(applications)
          .where(eq(applications.oportunitate_id, opportunityId))
          .orderBy(desc(applications.created_at));
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    return Array.from(this.memApplications.values())
      .filter(application => application.oportunitate_id === opportunityId)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    if (useDatabase && db) {
      try {
        const result = await db.insert(applications).values(insertApplication).returning();
        return result[0];
      } catch (error) {
        console.warn("Database error, falling back to memory:", error);
      }
    }
    const id = randomUUID();
    const application: Application = { 
      ...insertApplication, 
      id, 
      created_at: new Date(),
      mesaj: insertApplication.mesaj || null
    };
    this.memApplications.set(id, application);
    return application;
  }
}

export const storage = new HybridStorage();

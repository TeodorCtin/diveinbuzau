import { neon } from "@neondatabase/serverless";

export async function initializeDatabase() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL environment variable is required");
  }

  const sql = neon(process.env.DATABASE_URL);

  try {
    // Create tables if they don't exist
    await sql`
      CREATE TABLE IF NOT EXISTS "users" (
        "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
        "email" text NOT NULL,
        "password" text NOT NULL,
        "nume_organizatie" text NOT NULL,
        "created_at" timestamp DEFAULT now() NOT NULL,
        CONSTRAINT "users_email_unique" UNIQUE("email")
      )
    `;

    await sql`
      CREATE TABLE IF NOT EXISTS "opportunities" (
        "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
        "user_id" varchar,
        "titlu" text NOT NULL,
        "descriere" text NOT NULL,
        "categorie" text NOT NULL,
        "data" text NOT NULL,
        "locatie" text NOT NULL,
        "contact_email" text,
        "link_extern" text,
        "imagine_url" text,
        "created_at" timestamp DEFAULT now() NOT NULL
      )
    `;

    await sql`
      CREATE TABLE IF NOT EXISTS "applications" (
        "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
        "oportunitate_id" varchar NOT NULL,
        "nume" text NOT NULL,
        "prenume" text NOT NULL,
        "email" text NOT NULL,
        "link_social" text NOT NULL,
        "mesaj" text,
        "created_at" timestamp DEFAULT now() NOT NULL
      )
    `;

    // Add foreign key constraints if they don't exist
    await sql`
      DO $$ BEGIN
        ALTER TABLE "opportunities" ADD CONSTRAINT "opportunities_user_id_users_id_fk" 
        FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE no action ON UPDATE no action;
      EXCEPTION
        WHEN duplicate_object THEN null;
      END $$
    `;

    await sql`
      DO $$ BEGIN
        ALTER TABLE "applications" ADD CONSTRAINT "applications_oportunitate_id_opportunities_id_fk" 
        FOREIGN KEY ("oportunitate_id") REFERENCES "opportunities"("id") ON DELETE no action ON UPDATE no action;
      EXCEPTION
        WHEN duplicate_object THEN null;
      END $$
    `;

    console.log("Database initialized successfully");
  } catch (error) {
    console.error("Error initializing database:", error);
    throw error;
  }
}
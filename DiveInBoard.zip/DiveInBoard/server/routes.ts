import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertOpportunitySchema, insertApplicationSchema } from "@shared/schema";
import bcrypt from "bcrypt";

// Extend session data type
declare module "express-session" {
  interface SessionData {
    userId?: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email-ul este deja folosit" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });

      // Don't send password back
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Email sau parolă incorectă" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Email sau parolă incorectă" });
      }

      // Set session
      req.session.userId = user.id;
      
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err: any) => {
      if (err) {
        return res.status(500).json({ message: "Eroare la deconectare" });
      }
      res.json({ message: "Deconectat cu succes" });
    });
  });

  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        // Don't reveal if email exists or not for security
        return res.json({ message: "Dacă emailul există, vei primi instrucțiuni de resetare." });
      }

      // In a real app, you would:
      // 1. Generate a secure reset token
      // 2. Store it in database with expiration
      // 3. Send email with reset link
      // For now, just return success message
      console.log(`Password reset requested for ${email}`);
      
      res.json({ message: "Dacă emailul există, vei primi instrucțiuni de resetare." });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    try {
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Nu ești autentificat" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(401).json({ message: "Utilizator nu a fost găsit" });
      }

      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Opportunity routes
  app.get("/api/opportunities", async (req, res) => {
    try {
      const opportunities = await storage.getOpportunities();
      res.json(opportunities);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/opportunities/:id", async (req, res) => {
    try {
      const opportunity = await storage.getOpportunity(req.params.id);
      if (!opportunity) {
        return res.status(404).json({ message: "Oportunitatea nu a fost găsită" });
      }
      res.json(opportunity);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/opportunities", async (req, res) => {
    try {
      const opportunityData = insertOpportunitySchema.parse(req.body);
      const opportunity = await storage.createOpportunity(opportunityData);
      res.json(opportunity);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/opportunities/:id", async (req, res) => {
    try {
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Nu ești autentificat" });
      }

      const existing = await storage.getOpportunity(req.params.id);
      if (!existing) {
        return res.status(404).json({ message: "Oportunitatea nu a fost găsită" });
      }

      if (existing.user_id !== userId) {
        return res.status(403).json({ message: "Nu ai permisiunea să editezi această oportunitate" });
      }

      const updateData = insertOpportunitySchema.partial().parse(req.body);
      const updated = await storage.updateOpportunity(req.params.id, updateData);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/opportunities/:id", async (req, res) => {
    try {
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Nu ești autentificat" });
      }

      const existing = await storage.getOpportunity(req.params.id);
      if (!existing) {
        return res.status(404).json({ message: "Oportunitatea nu a fost găsită" });
      }

      if (existing.user_id !== userId) {
        return res.status(403).json({ message: "Nu ai permisiunea să ștergi această oportunitate" });
      }

      const deleted = await storage.deleteOpportunity(req.params.id);
      if (deleted) {
        res.json({ message: "Oportunitatea a fost ștearsă" });
      } else {
        res.status(500).json({ message: "Eroare la ștergerea oportunității" });
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/my-opportunities", async (req, res) => {
    try {
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Nu ești autentificat" });
      }

      const opportunities = await storage.getOpportunitiesByUser(userId);
      res.json(opportunities);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Application routes
  app.post("/api/applications", async (req, res) => {
    try {
      const applicationData = insertApplicationSchema.parse(req.body);
      
      // Get the opportunity to check if it has external link
      const opportunity = await storage.getOpportunity(applicationData.oportunitate_id);
      if (!opportunity) {
        return res.status(404).json({ message: "Oportunitatea nu a fost găsită" });
      }
      
      // Always store the application data first
      const application = await storage.createApplication(applicationData);
      
      // If opportunity has external link, return it for redirect
      if (opportunity.link_extern) {
        return res.json({ 
          application,
          redirect_url: opportunity.link_extern,
          message: "Aplicația a fost înregistrată. Vei fi redirectionat pentru a continua procesul."
        });
      }
      
      // For internal applications, just confirm success
      res.json({ 
        application,
        message: "Aplicația ta a fost trimisă cu succes! Organizația va fi contactată."
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/applications/opportunity/:opportunityId", async (req, res) => {
    try {
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Nu ești autentificat" });
      }

      // Check if user owns the opportunity
      const opportunity = await storage.getOpportunity(req.params.opportunityId);
      if (!opportunity || opportunity.user_id !== userId) {
        return res.status(403).json({ message: "Nu ai permisiunea să vezi aceste aplicații" });
      }

      const applications = await storage.getApplicationsByOpportunity(req.params.opportunityId);
      res.json(applications);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

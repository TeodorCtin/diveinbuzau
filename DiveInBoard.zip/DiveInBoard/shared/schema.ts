import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  nume_organizatie: text("nume_organizatie").notNull(),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const opportunities = pgTable("opportunities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  user_id: varchar("user_id").references(() => users.id),
  titlu: text("titlu").notNull(),
  descriere: text("descriere").notNull(),
  categorie: text("categorie").notNull(),
  data: text("data").notNull(),
  locatie: text("locatie").notNull(),
  contact_email: text("contact_email"),
  link_extern: text("link_extern"),
  imagine_url: text("imagine_url"),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const applications = pgTable("applications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  oportunitate_id: varchar("oportunitate_id").references(() => opportunities.id).notNull(),
  nume: text("nume").notNull(),
  prenume: text("prenume").notNull(),
  email: text("email").notNull(),
  link_social: text("link_social").notNull(),
  mesaj: text("mesaj"),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  created_at: true,
});

export const insertOpportunitySchema = createInsertSchema(opportunities).omit({
  id: true,
  created_at: true,
}).extend({
  descriere: z.string().max(1000, "Descrierea nu poate depăși 1000 de caractere"),
});

export const insertApplicationSchema = createInsertSchema(applications).omit({
  id: true,
  created_at: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertOpportunity = z.infer<typeof insertOpportunitySchema>;
export type Opportunity = typeof opportunities.$inferSelect;
export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type Application = typeof applications.$inferSelect;
